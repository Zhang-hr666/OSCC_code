################### 08 Network visualization #######################
## Aims:
## => 1. Fantasy plots showing the TF-target relationships.
library(Seurat)
library(tidyverse)
library(ggraph)
library(tidygraph)
source("R/IO.R")

data <- LoadpySCENICOutput(regulon.gmt = "output/02-ifnb_pbmc.regulons.gmt",
                           adj.mat.file = "output/01-step1_adj.tsv")
head(data)
summary(data$importance)
data <- subset(data, importance > 1)

### 展示调控IFN-gamma通路的转录调控网络
hallmarks <- clusterProfiler::read.gmt("resource/h.all.v2022.1.Hs.symbols.gmt")
genes <- subset(hallmarks, term == "HALLMARK_INTERFERON_GAMMA_RESPONSE")$gene
source("R/network_plot.R")

RegulonGraphVis(data, tf.show = c("STAT2", "STAT1", "IRF7", "IRF2", "IRF8", "ETV7", "ELF1"),
                targets.show = genes)

RegulonGraphVis(data, tf.show = c("STAT2", "STAT1", "IRF7", "IRF2", "IRF8", "ETV7", "ELF1"),
                targets.show = genes, layout = "circle")

RegulonGraphVis(data, tf.show = c("STAT2", "STAT1", "IRF7", "IRF2", "IRF8", "ETV7", "ELF1"),
                targets.show = genes, prop = 0.01)

RegulonGraphVis(data, tf.show = c("STAT2", "STAT1", "IRF7", "IRF2", "IRF8", "ETV7", "ELF1"),
                targets.show = genes, prop = NULL, n = 20)
