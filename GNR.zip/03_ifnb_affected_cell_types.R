################### After SCENIC #######################
## Aims:
## 从SCENIC outputs到生物学假设
## Input data: PBMC (ctrl vs IFNB simulated)
## => 1. 受到IFNB影响最大的PBMC细胞类型是什么?        | cellular level
##    2. 哪些TF驱动了IFNB simulated PBMC的转录组变化? | Molecular level
##    3. 哪些TF驱动了哪些细胞类型的什么样的变化?
##       (下游的基因, related to某些生物学功能)       | Functional level
rm(list = ls())
library(Seurat)
library(tidyverse)
library(patchwork)
setwd(here::here())
source("R/compute_module_score.R")

## 导入Seurat对象
seu <- readRDS("data/555OSCChamony_seurat_annotaion.rds")
colnames(seu@meta.data)[colnames(seu@meta.data) == "celltype_sub"] <- "celltype"

####只留成纤维
seu <- subset(seu, celltype %in% c("Fibroblast"))
DimPlot(seu, group.by = "celltype", reduction = "umap", label = T)
celltype.levels <- c("T/NK", "Epithelial", "Macrophages","Fibroblast", "Endothelial", "B/Plasma",
                     "Mast", "DC", "Myocytes")
# celltype.levels <- c("Fibroblast")
seu$celltype <- factor(seu$celltype, levels = celltype.levels)

## 导入regulon (gene list)
regulons <- clusterProfiler::read.gmt("output/02-ifnb_pbmc.regulons.gmt")
## data.frame -> list, list中的每个元素为一个gene set
rg.names <- unique(regulons$term)
regulon.list <- lapply(rg.names, function(rg) {
  subset(regulons, term == rg)$gene
})
names(regulon.list) <- sub("[0-9]+g", "\\+", rg.names)
summary(sapply(regulon.list, length))
print(regulon.list[1])
# saveRDS(regulon.list, "output/03-1.OSCC_0.8_onlyFib.regulons.rds")

## 用AUCell计算RAS matrix
## RAS = regulon activity score
seu <- ComputeModuleScore(seu, gene.sets = regulon.list, min.size = 10, cores = 1)
seu
# p1 <- FeaturePlot(seu, features = "STAT2(+)", split.by = "group")
# p2 <- FeaturePlot(seu, features = "STAT2", split.by = "group")
# (p1 / p2) & scale_color_viridis_c()
#
# VlnPlot(seu, group.by = "celltype", features = "STAT2(+)", pt.size = 0,
#         split.by = "group", split.plot = TRUE, cols = c("blue", "red")) + ylab("TF activity")
# VlnPlot(seu, group.by = "celltype", features = "STAT2", pt.size = 0,
#         split.by = "group", split.plot = TRUE, cols = c("blue", "red"))
##devtools::install_version("Matrix",version = "1.6-1.1")
##devtools::install_version("Matrix")
## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = rownames(seu),
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRAS",
               reduction.key = "umapRAS_")
## 可视化：UMAP on harmony
p1 <- DimPlot(seu, reduction = "umap", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p2 <- DimPlot(seu, reduction = "umap", group.by = "group") + NoLegend()
p6 <- DimPlot(seu, reduction = "umap", split.by = "group")  + NoLegend()
p1  + p2
## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "group")
p5 <- DimPlot(seu, reduction = "umapRAS", split.by = "group")
(p1 +p3) / (p2 + p4)
(p1 + p3) / (p2 + p5)

## 推测：INFB对髓系细胞的影响更大

## 换一种方式：PCA
DefaultAssay(seu) <- "AUCell"
seu <- ScaleData(seu)
seu <- RunPCA(object = seu,
              features = rownames(seu),
              reduction.name = "pcaRAS",
              reduction.key = "pcaRAS_")

## 可视化：PCA on RAS
p3 <- DimPlot(seu, reduction = "pcaRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "pcaRAS", group.by = "group")
p5 <- DimPlot(seu, reduction = "pcaRAS", split.by = "group")
p3 + p4
p3 + p4+p5
## PC1 encoding the regulons related to cell type
## PC2 encoding the regulons affected by INFB treatment
## The INFB induced transcriptome shift is orthogonal to the cell identity transcriptional programs.

VlnPlot(seu, group.by = "celltype", features = "pcaRAS_1", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red"))

VlnPlot(seu, group.by = "celltype", features = "pcaRAS_2", pt.size = 0,
        split.by = "group", split.plot = TRUE, cols = c("blue", "red"))
qs::qsave(seu, "output/03-2.OSCC_0.8onlyFib.aucell.qs")
qs::qsave(seu, "output/03-2.OSCC_all.aucell.qs")
#qs::qsave(seu1, "output/03-2.OSCC_0.8onlyFib二次降维.aucell.qs")
#######改一下
seu <- qs::qread("output/03-2.OSCC_deEpithelialc.aucell.qs")
metadata <- seu@meta.data
table(seu@meta.data$celltype)
# 将 'Cancer stem cell' 替换为 'Epithelial'
seu@meta.data$celltype[seu@meta.data$celltype == 'Cancer stem cell'] <- 'Epithelial'

# 检查修改后的结果
table(seu@meta.data$celltype)
p1 <- DimPlot(seu, reduction = "umap", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p2 <- DimPlot(seu, reduction = "umap", group.by = "group") + NoLegend()
p6 <- DimPlot(seu, reduction = "umap", split.by = "group")  + NoLegend()
p1  + p2
## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "group")
p5 <- DimPlot(seu, reduction = "umapRAS", split.by = "group")
(p1 +p3) / (p2 + p4)




