################### 03 After SCENIC #######################
## Aims:
## 从SCENIC outputs到生物学假设
## Input data: PBMC (ctrl vs INFB simulated)
## 1. 受到INFB影响最大的PBMC细胞类型是什么?        | cellular level
## 2. 哪些TF驱动了INFB simulated PBMC的转录组变化? | Molecular level
## 3. 哪些TF驱动了哪些细胞类型的什么样的变化?
##    (下游的基因, related to某些生物学功能)       | Functional level
rm(list = ls())
library(Seurat)
library(tidyverse)
library(patchwork)
setwd(here::here())
source("R/compute_module_score.R")

############# Q1 ###################

## 导入Seurat对象
seu <- readRDS("data/OSCC_deEpithelial_seurat_annotaion_subcluster.rds")
## 导入regulon (gene list)
regulons <- clusterProfiler::read.gmt("output/02-ifnb_pbmc.regulons.gmt")
## data.frame -> list, list中的每个元素为一个gene set
rg.names <- unique(regulons$term)
regulon.list <- lapply(rg.names, function(rg) {
  subset(regulons, term == rg)$gene
})
names(regulon.list) <- sub("[0-9]+g", "\\+", rg.names)
summary(sapply(regulon.list, length))
print(regulon.list[1])
saveRDS(regulon.list, "output/03-1.OSCC_deEpithelial.regulons.rds")

## 用AUCell计算RAS matrix
## RAS = regulon activity score
seu <- ComputeModuleScore(seu, gene.sets = regulon.list, min.size = 10, cores = 30)
seu
DefaultAssay(seu) <- "AUCell"

p1 <- FeaturePlot(seu, features = "STAT2(+)", split.by = "group")
p2 <- FeaturePlot(seu, features = "STAT2", split.by = "group")
(p1 / p2) & scale_color_viridis_c()

## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = rownames(seu),
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRAS",
               reduction.key = "umapRAS_")

## 可视化：UMAP on harmony
p1 <- DimPlot(seu, reduction = "umap", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p2 <- DimPlot(seu, reduction = "umap", group.by = "group") + NoLegend()

## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "group")

(p1 + p3) / (p2 + p4)

## 推测：INFB对髓系细胞的影响更大

## 换一种方式：PCA
DefaultAssay(seu) <- "AUCell"
seu <- ScaleData(seu)
seu <- RunPCA(object = seu,
              features = rownames(seu),
              reduction.name = "pcaRAS",
              reduction.key = "pcaRAS_")

## 可视化：PCA on RAS
p3 <- DimPlot(seu, reduction = "pcaRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "pcaRAS", group.by = "group")
p3 + p4

## PC1 encoding the regulons related to cell type
## PC2 encoding the regulons affected by INFB treatment
## The INFB induced transcriptome shift is orthogonal to the cell identity transcritional programs.

############# Q2 ###################
## PC2 high loading regulons
seu[["pcaRAS"]]@feature.loadings[, 2] %>% sort() %>% head()
seu[["pcaRAS"]]@feature.loadings[, 2] %>% sort() %>% tail()

p1 <- FeaturePlot(seu, reduction = "pcaRAS", features = "IRF9(+)")
p2 <- FeaturePlot(seu, reduction = "pcaRAS", features = "IRF9")
(p1 | p2) & scale_color_viridis_c()

p1 <- FeaturePlot(seu, reduction = "pcaRAS", features = "FOS(+)")
p2 <- FeaturePlot(seu, reduction = "pcaRAS", features = "FOS")
(p1 | p2) & scale_color_viridis_c()

## regulon module
rasMat <- seu[["AUCell"]]@data
rasMat <- t(rasMat)
pccMat <- cor(rasMat) # 对列计算相关性

# 计算Connection Specificity Index (CSI)
CSI <- function(r1, r2) {
  delta <- pccMat[r1,r2]
  r.others <- setdiff(colnames(pccMat), c(r1,r2))
  N <- sum(pccMat[r1, r.others] < delta) + sum(pccMat[r2, r.others] < delta)
  M <- length(r.others) * 2
  return(N/M)
}

csiMat <- pbapply::pblapply(rownames(pccMat), function(i) sapply(colnames(pccMat), function(j) CSI(i, j)))
csiMat <- do.call(rbind, csiMat)
rownames(csiMat) <- rownames(pccMat)

## 找到一个合适的h for cut tree
library(dendextend)
library(ggsci)
h = 4
row_dend = as.dendrogram(hclust(dist(pccMat), method = "complete"))
clusters <- dendextend::cutree(row_dend, h = h) # dendextend::cutree()
row_dend = color_branches(row_dend, h = h, col = pal_d3("category20")(20))
plot(row_dend)

## 聚类可视化
library(ComplexHeatmap)
library(circlize)

col_range = c(0, 1)
col_fun <- colorRamp2(col_range, c("#FCF8DE", "#253177"))

for(i in nrow(pccMat)) {
  pccMat[i, i] <- 0
}

ht <- Heatmap(
  matrix = pccMat,
  col = col_fun,
  name = "ht1",
  cluster_rows = TRUE,
  cluster_columns = TRUE,
  show_column_names = FALSE,
  show_row_names = FALSE,
  show_heatmap_legend = FALSE
)

lgd <- Legend(
  col_fun = col_fun,
  title = "",
  at = col_range,
  labels = c("low", "high"),
  direction = "horizontal",
  legend_width = unit(1, "in"),
  border = FALSE
)

{
  draw(ht, heatmap_legend_list = list(lgd), heatmap_legend_side = c("bottom"))
  decorate_heatmap_body("ht1", {
    tree = column_dend(ht)
    ind = cutree(as.hclust(tree), h = h)[order.dendrogram(tree)]
    first_index = function(l) which(l)[1]
    last_index = function(l) { x = which(l); x[length(x)] }
    clusters <- names(table(ind))
    x1 = sapply(clusters, function(x) first_index(ind == x)) - 1
    x2 = sapply(clusters, function(x) last_index(ind == x))
    x1 = x1/length(ind)
    x2 = x2/length(ind)
    grid.rect(x = x1, width = (x2 - x1), y = 1-x1, height = (x1 - x2),
              hjust = 0, vjust = 0, default.units = "npc",
              gp = gpar(fill=NA, col="#FCB800", lwd=3))
    grid.text(label = paste0("M",clusters),
              x = x2-length(clusters)/length(ind), y = 1-x1-(x2-x1)/2,
              default.units = "npc",
              hjust = 1, vjust = 0.5,
              gp = gpar(fontsize=12, fontface="bold"))
  })
  decorate_column_dend("ht1", {
    tree = column_dend(ht)
    ind = cutree(as.hclust(tree), h = h)[order.dendrogram(tree)]
    first_index = function(l) which(l)[1]
    last_index = function(l) { x = which(l); x[length(x)] }
    clusters <- names(table(ind))
    x1 = sapply(clusters, function(x) first_index(ind == x)) - 1
    x2 = sapply(clusters, function(x) last_index(ind == x))
    grid.rect(x = x1/length(ind), width = (x2 - x1)/length(ind), just = "left",
              default.units = "npc", gp = gpar(fill = pal_d3("category20")(20), alpha=.5, col = NA))
  })
}

tree <- column_dend(ht)
ind <- cutree(as.hclust(tree), h = h)[order.dendrogram(tree)]
clusters <- names(table(ind))
regulon.clusters <- data.frame(regulon=names(ind), cluster=paste0("M",ind))
table(regulon.clusters$cluster)
regulon.clusters
saveRDS(regulon.clusters, "output/03-2.infb_pbmc.regulon_modules.rds")

# 绘制每个regulon-module的平均活性
k = length(clusters)
cell.info <- seu@meta.data
moduleRasMat <- lapply(paste0("M",1:k), function(x){
  regulon.use <- subset(regulon.clusters, cluster == x)$regulon
  rowMeans(rasMat[, regulon.use, drop=FALSE])
})
names(moduleRasMat) <- paste0("M",1:k)
moduleRasMat <- do.call(cbind, moduleRasMat)
cell.info <- cbind(cell.info, moduleRasMat[rownames(cell.info), ])

cell.info <- cbind(cell.info, FetchData(seu, vars = paste0("umap_", 1:2)))

p.list <- lapply(paste0("M",1:k), function(module){
  data.use <- cell.info
  expression.color <- c("darkblue", "lightblue", "green", "yellow", "red")
  max.val <- quantile(data.use[, module], 0.99)
  low.val <- quantile(data.use[, module], 0.1)
  data.use[, module] <- ifelse(data.use[, module] > max.val, max.val, data.use[, module])
  ggplot(data.use, aes(umap_1, umap_2, color=get(module))) +
    geom_point(size=0.05) +
    theme_bw(base_size = 15) +
    ggtitle(module) +
    facet_wrap(~group) +
    scale_color_gradientn(name = NULL, colors = expression.color) +
    theme(legend.position = "right",
          legend.title = element_blank(),
          plot.title = element_text(hjust = .5, face = "bold", size = 20),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          axis.line = element_line(color="black")
    )
})

cowplot::plot_grid(plotlist = p.list, ncol = 3)

############# Q3 ###################
## TF module: a list of regulons
## regulon:   a list of genes
## genes?? enrichment !!

## TF module 展开成一个基因集合 + 富集分析 = 外源信号 -> TF -> 功能基因
regulon.clusters <- readRDS("output/03-2.infb_pbmc.regulon_modules.rds")

rms <- unique(regulon.clusters$cluster)
module.list <- lapply(rms, function(xx) subset(regulon.clusters, cluster == xx)$regulon)
names(module.list) <- rms

regulon.list <- readRDS("output/03-1.infb_pbmc.regulons.rds")

regulon.module.genes <- lapply(seq_along(module.list), function(xx) {
  unique(unlist(regulon.list[module.list[[xx]] ]))
})
names(regulon.module.genes) <- names(module.list)

sapply(regulon.module.genes, length)

## 富集分析
library(clusterProfiler)

t2g <- readRDS("resource/msigdb.all.human_symbol.rds")

eres.list <- lapply(sort(names(regulon.module.genes)), function(clu) {
  message(glue::glue("processing {clu} ..."))
  genes <- regulon.module.genes[[clu]]
  ## downsample to speed up the calculation
  if (length(genes) >= 200) {
    genes <- sample(genes, size = 200)
  }
  clusterProfiler::enricher(gene = genes, TERM2GENE = t2g, pvalueCutoff = 1, minGSSize = 0)
})
names(eres.list) <- sort(names(regulon.module.genes))

## plot data
data.use <- lapply(names(eres.list), function(xx) {
  res <- subset(eres.list[[xx]]@result, grepl("^GO_", ID)) # only show GO results
  res <- head(res, 5)
  res$group <- xx
  res
}) %>% Reduce(rbind, .)

term.levels <- unique(data.use$Description)

data.use <- lapply(names(eres.list), function(xx) {
  res <- subset(eres.list[[xx]]@result, Description %in% term.levels)
  res$group <- xx
  res
}) %>% Reduce(rbind, .)

data.use$Description <- factor(data.use$Description, levels = rev(term.levels))
data.use <- subset(data.use, p.adjust < 0.05 & Count > 2)

## plot
ggplot(data.use, aes(group, Description)) +
  geom_point(aes(size = Count, fill = -log10(p.adjust)), shape=21, color = "black") +
  scale_fill_gradientn(colors = c("white","red")) +
  scale_y_discrete(labels = function(x) str_wrap(x, width = 50)) +
  labs(x = "gene cluster") +
  theme_bw(base_size = 13) +
  theme(axis.title.y = element_blank(),
        axis.text = element_text(color = "black"))

qs::qsave(eres.list, "output/03-3.infb_pbmc.regulon_modules.enriched_terms.qs")
