library(Seurat)

seu <- qs::qread("output/03-2.ifnb_pbmc.seurat.aucell.qs")

#### 1. remove module F ####

regulon.cluster <- readRDS("output/05-1.regulon_clusters_network.rds")
regulons.F <- subset(regulon.cluster, cluster == "F")$TF
regulons.F <- paste0(regulons.F, "(+)")
features.use <- setdiff(rownames(seu), regulons.F)
## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = features.use,
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRASrmF",
               reduction.key = "umapRASrmF_")

## 可视化：UMAP on harmony
p1 <- DimPlot(seu, reduction = "umap", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p2 <- DimPlot(seu, reduction = "umap", group.by = "group") + NoLegend()

## 可视化：UMAP on RAS
p3 <- DimPlot(seu, reduction = "umapRAS", group.by = "celltype") + ggsci::scale_color_d3("category20") + NoLegend()
p4 <- DimPlot(seu, reduction = "umapRAS", group.by = "group") + NoLegend()

## 可视化：UMAP on RAS (remove module F)
p3 <- DimPlot(seu, reduction = "umapRASrmF", group.by = "celltype") + ggsci::scale_color_d3("category20")
p4 <- DimPlot(seu, reduction = "umapRASrmF", group.by = "group")

(p1 | p3 | p5) / (p2 | p4 | p6)



#### 2. remove M5,6,11 ####

regulon.cluster <- readRDS("output/05-2.regulon_clusters_activity_similarity.rds")
## 去除M5,6,11的regulon
regulons.rm <- subset(regulon.cluster, cluster %in% paste0("M",c(5,6,11)))$regulon
features.use <- setdiff(rownames(seu), regulons.rm)
## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = features.use,
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRASrm",
               reduction.key = "umapRASrm_")

## 可视化：UMAP on RAS (remove M5,6,11)
p5 <- DimPlot(seu, reduction = "umapRASrm", group.by = "celltype") + ggsci::scale_color_d3("category20")
p6 <- DimPlot(seu, reduction = "umapRASrm", group.by = "group")

(p1 | p3 | p5) / (p2 | p4 | p6)



#### 3. remove group specific regulons ####

## 去group特异的regulon
vd.res <- readRDS("output/04-1.VD_res.rds")
regulons.rm <- subset(vd.res, group > 0.1)$gene
features.use <- setdiff(rownames(seu), regulons.rm)

## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = features.use,
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRASrm",
               reduction.key = "umapRASrm_")

## 可视化：UMAP on RAS (remove group > 0.1)
p5 <- DimPlot(seu, reduction = "umapRASrm", group.by = "celltype") + ggsci::scale_color_d3("category20")
p6 <- DimPlot(seu, reduction = "umapRASrm", group.by = "group")

(p1 | p3 | p5) / (p2 | p4 | p6)



#### 4. remove celltype specific regulons ####
regulons.rm <- subset(vd.res, celltype > 0.1)$gene
features.use <- setdiff(rownames(seu), regulons.rm)

## 用RAS matrix计算UMAP
seu <- RunUMAP(object = seu,
               features = features.use,
               metric = "correlation", # 注意这里用correlation效果最好
               reduction.name = "umapRASrmct",
               reduction.key = "umapRASrmct_")

## 可视化：UMAP on RAS (remove celltype > 0.1)
p7 <- DimPlot(seu, reduction = "umapRASrmct", group.by = "celltype") + ggsci::scale_color_d3("category20")
p8 <- DimPlot(seu, reduction = "umapRASrmct", group.by = "group")

(p1 | p3 | p5 | p7) / (p2 | p4 | p6 | p8)
