## Aims:
## 哪些转录因子驱动了IFNB处理组的转录组变化
## IFNB(外源刺激) -> TF(GRN) -> 转录组的变化 -> 通路/生物学过程的变化
## SCENIC: 转录组 (~1000 genes) -> TF activity (GRN) (~10 TFs)

################### 00 Meta cell #######################
## Aims:
## 降低细胞数，增加数据的信噪比 -> fill the zeros
## 加快pySCENIC的计算速度
## 准备pySCENIC的输入文件:
## 1. 基因表达矩阵, meta cell matrix (For grnboost, step1)
## 2. TF list, download from
###   (1) 自定义
###   (2) SCENIC: https://resources.aertslab.org/cistarget/tf_lists/allTFs_hg38.txt
###   (3) AnimalTFDB: http://bioinfo.life.hust.edu.cn/AnimalTFDB4/static/download/TF_list_final/Homo_sapiens_TF
## 注意：我们提供的TF list仅用于grnboost算法(step1)，如果我们提供的TF list不在motif annotation文件里，那么这个TF的regulon不会出现在最终的结果中
## 3. 参考文件:
###   (1) motif ranking tracks (.feather, 二进制文件, rows are motifs, columns are genes, values are ranks)
###   (2) motif annotation     (.tbl, txt文件, motif -> TFs)
rm(list = ls())
library(Seurat)
library(tidyverse)
setwd(here::here())
source("R/makeMetaCells.R")
if (!dir.exists("output")) {
  dir.create("output")
}

### 读入数据
## clusters were annotated after batch effect removal via harmony.
seu <- readRDS("data/OSCC_0.8_seurat_annotaion_subcluster.rds")
DimPlot(seu, group.by = "celltype", split.by = "group") & ggsci::scale_color_d3("category20")

### 创建meta cell
## 按样本处理
seu.list <- SplitObject(seu, split.by = "orig.ident")
seu.list[[1]]@project.name <- "N1"
seu.list[[2]]@project.name <- "N2"
seu.list[[3]]@project.name <- "N3"
seu.list[[4]]@project.name <- "OSCC1"
seu.list[[5]]@project.name <- "OSCC12"
seu.list[[6]]@project.name <- "OSCC13"
seu.list[[7]]@project.name <-"OSCC14"
seu.list[[8]]@project.name <- "OSCC15"
seu.list[[9]]@project.name <- "OSCC19"
seu.list[[10]]@project.name <- "OSCC2"
seu.list[[11]]@project.name <- "OSCC20"
seu.list[[12]]@project.name <- "OSCC3"
seu.list[[13]]@project.name <- "OSCC4"
seu.list[[14]]@project.name <- "OSCC5"
seu.list[[15]]@project.name <- "OSCC6"
seu.list[[16]]@project.name <- "OSCC7"
seu.list[[17]]@project.name <-"OSCC8"
seu.list[[18]]@project.name <- "OSCC9"
metacells.list <- lapply(seq_along(seu.list), function(ii) {
  makeMetaCells(
    seu       = seu.list[[ii]],
    min.cells = 10,
    reduction = "umap",
    dims      = 1:2,
    k.param   = 10,
    cores     = 1)
})

mc.mat <- lapply(metacells.list, function(mc) mc$mat) %>% Reduce(cbind, .)
mc.cellmeta <- lapply(metacells.list, function(mc) mc$metadata) %>% Reduce(rbind, .)

## 直观感受一下meta cell的好处
seu2 <- CreateSeuratObject(mc.mat)
seu2 <- NormalizeData(seu2)
FeatureScatter(seu, feature1 = "CD8A", feature2 = "CD8B") +
FeatureScatter(seu2, feature1 = "CD8A", feature2 = "CD8B")

## 保存结果(meta cell matrix)
saveRDS(mc.mat, "output/OSCC_deEpi00-1.mc.mat.rds")


## 准备pySCENIC的输入文件

## (1) TF list文件(optional)，可以使用预定义的TF list，例如pySCENIC官方提供的，或者animalTFDB提供的。
motif2tfs <- data.table::fread("cisTarget_db/motifs-v10nr_clust-nr.hgnc-m0.001-o0.0.tbl")
TFs <- sort(unique(motif2tfs$gene_name))
writeLines(TFs, "cisTarget_db/hsa_hgnc_tfs.motifs-v10.txt")

## (2) meta cell matrix (for step1): *.csv or *.loom
mc.mat <- readRDS("output/OSCC_deEpi00-1.mc.mat.rds")
## (2.1) 过滤低表达基因
expr.in.cells <- rowSums(mc.mat > 0)
mc.mat <- mc.mat[expr.in.cells >= 5, ]
## (2.2) 过滤不在cisTargetDB中的基因
cisdb <- arrow::read_feather("cisTarget_db/hg38_10kbp_up_10kbp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather")
genes.use <- intersect(colnames(cisdb), rownames(mc.mat))
length(genes.use)
dim(mc.mat)
mc.mat <- mc.mat[genes.use, ]
dim(mc.mat)

## 保存为loom文件
loom <- SCopeLoomR::build_loom(
  file.name         = "output/00-2.mc_mat_for_step1.loom",
  dgem              = mc.mat,
  default.embedding = NULL
)
loom$close()

## 释放loom对象，允许其它文件占用loom文件
rm(loom)
gc()

