################### After SCENIC #######################
## Aims:
## 从SCENIC outputs到生物学假设
## Input data: PBMC (ctrl vs IFNB simulated)
##    1. 受到IFNB影响最大的PBMC细胞类型是什么?        | cellular level
## => 2. 哪些TF驱动了IFNB simulated PBMC的转录组变化? | Molecular level
##       (1) 鉴定差异regulon
##    3. 哪些TF驱动了哪些细胞类型的什么样的变化?
##       (下游的基因, related to某些生物学功能)       | Functional level
rm(list = ls())
library(Seurat)
library(tidyverse)
library(patchwork)
setwd(here::here())


## 导入Seurat对象
seu <- qs::qread("output/03-2.OSCC_0.8onlyFib.aucell.qs")

#### Method 1: feature loadings of PCA ####
p1 <- DimPlot(seu, reduction = "pcaRAS", group.by = "celltype") + ggsci::scale_color_d3("category20")
p2 <- DimPlot(seu, reduction = "pcaRAS", group.by = "group")
p1 + p2

VlnPlot(seu, group.by = "celltype", features = "pcaRAS_2", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("blue", "red"))

## PC2-high-loading regulons
## gene expression matrix (cells x genes) = cell embeddings (cells x nPCs) %*% feature loadings (nPCs x genes)
## Here, only the high variable genes were involved.
## If you want to fetch all genes loadings, you should perform ProjectDim first
# seu <- ProjectDim(seu, reduction = "pcaRAS", do.center = T)
# We didn't need do this because we use all regulons to perform PCA.
Loadings(seu, reduction = "pcaRAS")
VizDimLoadings(seu, reduction = "pcaRAS", dims = 2, balanced = T, projected = F)
# 加载 gridExtra 包
library(gridExtra)
P1 <- VlnPlot(seu, group.by = "celltype", features = "JUNB(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("#66c2a5", "#fc8d62")) + ylab("TF activity")+ggtitle("JUNB(TF)")+
  theme(axis.text.x=element_text(angle =0, hjust = 0.5,vjust=0.5))+ NoLegend()
P2 <- VlnPlot(seu, group.by = "celltype", features = "KLF4(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("#66c2a5", "#fc8d62")) + ylab("TF activity")+ggtitle("KLF4(TF)")+
  theme(axis.text.x=element_text(angle =0, hjust = 0.5,vjust=0.5))+ NoLegend()
P3 <- VlnPlot(seu, group.by = "celltype", features = "MZF1(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("#66c2a5", "#fc8d62")) + ylab("TF activity")+ggtitle("MZF1(TF)")+
  theme(axis.text.x=element_text(angle =0, hjust = 0.5,vjust=0.5))+ NoLegend()
P4 <- VlnPlot(seu, group.by = "celltype", features = "SOX15(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("#66c2a5", "#fc8d62")) + ylab("TF activity")+ggtitle("SOX15(TF)")+
  theme(axis.text.x=element_text(angle =0, hjust = 0.5,vjust=0.5))+ NoLegend()
# 将四个图形排成一排
grid.arrange(P1, P2, P3, P4, nrow = 1)
#### Method 2: Variance Decomposition ####
source("R/variance_decompose.R")
DefaultAssay(seu) <- "AUCell"
vd.vars <- c("celltype", "group")
meta.data <- seu@meta.data[, vd.vars]
ras.data <- FetchData(seu, vars = rownames(seu))
vd.res <- VarDecompose(data = ras.data, meta.data = meta.data, vd.vars = vd.vars, cores = 5)

saveRDS(vd.res, "output/04-1.VD_res.rds")

## PCA和VD结果的一致性
vd.res$PC1.loadings <- Loadings(seu, reduction = "pcaRAS")[vd.res$gene, 1]
vd.res$PC2.loadings <- Loadings(seu, reduction = "pcaRAS")[vd.res$gene, 2]

to.label <- subset(vd.res, celltype > 0.25 & group > 0.15)

ggplot(vd.res, aes(celltype, group, color = abs(PC1.loadings))) +
  geom_point(size = 2) +
  geom_hline(yintercept = 0.15, color = "blue", linetype="dashed") +
  geom_vline(xintercept = 0.25, color = "blue", linetype="dashed") +
  ggrepel::geom_text_repel(inherit.aes = F, data = to.label, aes(celltype, group, label=gene)) +
  xlab("Fraction of variance by cell type") +
  ylab("Fraction of variance by group") +
  scale_color_viridis_c() +
  theme_bw(base_size = 15)

ggplot(vd.res, aes(celltype, group, color = abs(PC2.loadings))) +
  geom_point(size = 2) +
  xlab("Fraction of variance by cell type") +
  ylab("Fraction of variance by group") +
  scale_color_viridis_c() +
  theme_bw(base_size = 15)

ggplot(vd.res, aes(group)) +
  geom_density()

to.label <- subset(vd.res, group > 0.4)
ggplot(vd.res, aes(PC2.loadings, group)) +
  geom_point(size = 2) +
  ggrepel::geom_text_repel(inherit.aes = F, data = to.label, aes(PC2.loadings, group, label=gene)) +
  ylab("Fraction of variance by group") +
  theme_bw(base_size = 15)

VlnPlot(seu, group.by = "celltype", features = "HESX1(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("blue", "red")) + ylab("TF activity")
FeaturePlot(seu, reduction = "umap", features = "HESX1(+)", split.by = "group")
VlnPlot(seu, group.by = "celltype", features = "ETV6(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("blue", "red")) + ylab("TF activity")
FeaturePlot(seu, reduction = "umap", features = "ETV6(+)", split.by = "group")
VlnPlot(seu, group.by = "celltype", features = "IRF7(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F, cols = c("blue", "red")) + ylab("TF activity")
FeaturePlot(seu, reduction = "umap", features = "IRF7(+)", split.by = "group")


#### Method 3: DE test ####
source("R/de_regulon.R")
DefaultAssay(seu) <- "AUCell"
# should be factors
# change = STIM / CTRL
seu$group <- factor(seu$group, levels = c("CTRL", "STIM"))
de.list <- DERegulon(seu, celltype = "celltype", group = "group", test.use = "wilcox")

# avg_diff = STIM - CTRL
View(de.list[[1]])
summary(de.list[[1]]$avg_diff)

ggplot(de.list[[1]], aes(diff_rate, -log10(p_val_adj))) +
  geom_point()

de.regulons <- format_change(mylist = de.list, celltype.levels = levels(seu$celltype))

data.use <- full_join(vd.res, de.regulons, by = "gene")

## pull all results together
write_tsv(data.use, "output/04-2.de_regulons.tsv")

## check results
VlnPlot(seu, group.by = "celltype", features = "THRB(+)", split.by = "group",
        pt.size = 0, split.plot = TRUE, sort = F)

FeaturePlot(seu, reduction = "umap", split.by = "group", features = "THRB(+)") &
  scale_color_viridis_c()

FeaturePlot(seu, reduction = "umap", split.by = "group", features = "THRB") &
  scale_color_viridis_c()
