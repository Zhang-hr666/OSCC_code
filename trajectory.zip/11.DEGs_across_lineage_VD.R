#### Load packages ####
library(Seurat)
library(tidyverse)
library(patchwork)

setwd(here::here())

#### Load data ####
seu <- qs::qread("tmp/08.HS_BM_donor1.seurat.lineage.qs")

## Imputation by `MAGIC`(https://github.com/KrishnaswamyLab/MAGIC)
expr.in.cells <- Matrix::rowSums(seu[["RNA"]]@counts > 0)
select.features <- names(expr.in.cells[expr.in.cells >= 50])
seu.magic <- Rmagic::magic(seu, genes = select.features, seed=1024, npcs=30)
DefaultAssay(seu.magic) <- "MAGIC_RNA"

lineages <- c("Mono", "CLP")
p1 <- FeaturePlot(seu, reduction = "fr", features = c(lineages), ncol = 3) &
  scale_color_viridis_c()

p2 <- DimPlot(seu, reduction = "fr", group.by = paste0("lineage.finetune.", lineages), ncol = 3) &
  scale_color_manual(values = c("grey", "red")) &
  NoLegend()

p1 / p2


seu2 <- subset(seu, lineage.finetune.Mono | lineage.finetune.CLP)
seu2 <- subset(seu2, pseudotime <= 0.42)
VlnPlot(seu2, group.by = "celltype", features = "pseudotime") +
  geom_hline(yintercept = 0.42)
DimPlot(seu2, reduction = "fr", group.by = "celltype")

## LMM model
seu2$pseudotime.bin <- infotheo::discretize(seu2$pseudotime, disc = "equalwidth", 100)[[1]]
seu2$is.Mono <- seu2$Mono > 0.5
seu2$is.CLP <- seu2$CLP > 0.5

DimPlot(seu2, reduction = "fr", group.by = c("is.Mono", "is.CLP"), ncol = 2)

expr.in.cells <- Matrix::rowSums(seu2[["RNA"]]@counts > 0)
select.features <- names(expr.in.cells[expr.in.cells >= 50])
imputed.data <- FetchData(seu2, vars = select.features)
vd.vars <- c("pseudotime.bin", "is.Mono", "is.CLP")
meta.data <- seu2@meta.data[, vd.vars, drop = F]

dim(imputed.data) ## 12131 genes

## 1.5 min
system.time({
  vd.res <- Gadest::VarDecompose(data = imputed.data, meta.data = meta.data, vd.vars = vd.vars, cores = 20)
})

ggplot(vd.res, aes(is.Mono, is.CLP)) +
  geom_point(size = .2) +
  theme_bw(base_size = 15)

top5.mono <- head(arrange(vd.res, desc(is.Mono))$gene)
top5.CLP <- head(arrange(vd.res, desc(is.CLP))$gene)
top5.seudo <- head(arrange(vd.res, desc(pseudotime.bin))$gene)

FeaturePlot(seu.magic, reduction = "fr", features = c(top5.mono, top5.CLP), ncol = 6) &
  scale_color_viridis_c()

