#### Load packages ####
# remotes::install_github("mojaveazure/seurat-disk")
library(Seurat)
library(tidyverse)
library(magrittr)

setwd(here::here())
source("R/IO.R")
source("R/preprocess.R")


#### Load data ####
seu <- qs::qread("tmp/04.HS_BM_donor1.seurat.trajectory.qs")

## 读取loom文件
samples <- list.files("data/loom/")
samples <- samples[1:2]

ldat <- lapply(samples, function(fn) {
  message(glue::glue("Loading {fn} ..."))
  read.loom.matrices(file.path("data/loom/", fn))
})

names(ldat) <- sub(".loom", "", gsub("_", "-", samples))
sapply(ldat[[1]], dim)

## 合并loom文件
matrix.name <- names(ldat[[1]])
matrix.name

ldat.merged <- lapply(matrix.name, function(mn){
  mat.list <- lapply(ldat, function(xx) xx[[mn]])
  do.call(cbind, mat.list) ## merge by columns (cell.ID)
})
names(ldat.merged) <- matrix.name
sapply(ldat.merged, dim)

## Note: the cell.IDs in loom are inconsistent with those in `Seurat` object.
head(colnames(ldat.merged$spliced))
head(colnames(seu))

## fix the cell.IDs in loom
# gsub("_", "-", colnames(ldat.merged$spliced)) %>%
#   sub(":", "_", .) %>%
#   sub("x$", "-1", .) %>% head()

fix.cellID <- . %>% gsub("_", "-", .) %>% sub(":", "_", .) %>% sub("x$", "-1", .)

fix.cellID(colnames(ldat.merged$spliced)) %>% head()

for (i in seq_along(ldat.merged)) {
  colnames(ldat.merged[[i]]) %<>% fix.cellID()
}

## check the fixed cellID
# dim(seu)
# sapply(ldat.merged, dim)
#
# sapply(ldat.merged, function(xx) head(colnames(xx)))
colnames(seu) %in% colnames(ldat.merged$spliced) %>% all() ## should be TRUE

## filter cells
for (i in seq_along(ldat.merged)) {
  ldat.merged[[i]] <- ldat.merged[[i]][, colnames(seu)]
}
sapply(ldat.merged, dim)


#### Loom2Seurat ####
emat <- ldat.merged$spliced   # exonic read (spliced) expression matrix
nmat <- ldat.merged$unspliced # intronic read (unspliced) expression matrix

## drop the unexpressed genes
clusters <- seu$seurat_clusters
emat <- filter.genes.by.cluster.expression(emat, clusters, min.max.cluster.average = 0.1)
nmat <- filter.genes.by.cluster.expression(nmat, clusters, min.max.cluster.average = 0.01)

genes.use <- intersect(rownames(emat), rownames(nmat))
length(genes.use)

emat <- emat[genes.use, ]
nmat <- nmat[genes.use, ]

ldat2 <- list(
  spliced = emat,
  unspliced = nmat
)

sapply(ldat2, dim)

## New a Seurat object
seu2 <- as.Seurat(x = ldat2)
seu2
seu2[["RNA"]] <- seu2[["spliced"]]
DefaultAssay(seu2) <- "RNA"

## add meta.data
seu2@meta.data <- seu@meta.data

## add reductions
for (rd.name in Reductions(seu)) {
  seu2[[rd.name]] <- seu[[rd.name]]
}

## in case of the issue of `Convert`
## https://github.com/mojaveazure/seurat-disk/issues/134
## the dimensions of `feature.loading` should be consistent with the `scale.data`.
seu2[["pca"]]@feature.loadings <- matrix()

## `sceasy`无法将不同的assay写入同一个`h5ad`文件中，这里我们使用`SeuratDisk`的解决方案
## 当然，我们也可以通过`reticulate`来创建`anndata`，再保存为`h5ad`
SeuratDisk::SaveH5Seurat(seu2, filename = "tmp/06.HS_BM_donor1.h5Seurat", overwrite = TRUE)
SeuratDisk::Convert("tmp/06.HS_BM_donor1.h5Seurat", dest = "h5ad", overwrite = TRUE)

# seu <- SeuratDisk::LoadH5Seurat("tmp/06.HS_BM_donor1.h5Seurat")
