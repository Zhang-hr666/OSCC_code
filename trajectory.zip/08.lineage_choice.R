#### Load packages ####
rm(list = ls())
library(Seurat)
library(tidyverse)
library(igraph)

setwd(here::here())

#### 这玩意有啥用
#' 定义lineage

#### Load data ####
seu <- qs::qread("tmp/04.OSCCallFIB.seurat.trajectory.qs")

# seu <- subset(seu, celltype != "Mast cell")

## Load the palantir results
pr.res <- read.table("tmp/05.OSCCALLFIBpalantir1_results.csv", sep = ",", header = T, row.names = 1)

## Write to Seurat object
seu@meta.data <- pr.res

DimPlot(seu, reduction = "fr", group.by = "celltype", label = T)

#### Abstract Lineage: 最小生成树算法(Monocle V1) ####

## 过度聚类:
# k.clusters <- kmeans(x = Embeddings(seu, reduction = "diffusion.map")[,1:10], centers = 100)
# seu$seurat_clusters <- k.clusters$cluster
seu <- FindNeighbors(seu, reduction = "fr", dims = 1:2, k.param = 20)
seu <- FindClusters(seu, resolution = 8)

DimPlot(seu, reduction = "fr", group.by = "celltype", label = T) + NoLegend()

## the median cells for each cluster
data.use <- FetchData(seu, vars = c("seurat_clusters", "FDG_1", "FDG_2"))
data.use <- data.use %>%
  mutate(cellID = rownames(.)) %>%
  group_by(seurat_clusters) %>%
  mutate(x = abs(FDG_1 - median(FDG_1)),
         y = abs(FDG_2 - median(FDG_2)),
         d = x + y) %>%
  arrange(seurat_clusters, d) %>%
  slice_head(n=1)

DimPlot(seu, reduction = "fr", cells.highlight = data.use$cellID)


##
cell.embeddings <- Embeddings(seu, reduction = "fr")[data.use$cellID, ]
cell.pair.dis <- dist(cell.embeddings)
g <- igraph::graph_from_adjacency_matrix(adjmatrix = as.matrix(cell.pair.dis),
                                         mode = "undirected",
                                         weighted = TRUE,
                                         add.colnames = "cellID")

nodes2cellID <- get.vertex.attribute(g)$cellID
cellID2nodes <- setNames(1:length(nodes2cellID), nodes2cellID)

## 最小生成树
mst <- igraph::minimum.spanning.tree(g)
edges <- igraph::ends(mst, igraph::E(mst))
## Other spanning tree
# cell.pair.dis <- dist(cell.embeddings)
# dis.threshold <- 1
# cell.pair.dis <- as.matrix(cell.pair.dis)
# cell.pair.dis[cell.pair.dis > dis.threshold] <- 0
# g2 <- igraph::graph_from_adjacency_matrix(adjmatrix = cell.pair.dis,
#                                           mode = "undirected",
#                                           weighted = TRUE,
#                                           add.colnames = "cellID")
# edges <- igraph::ends(g2, igraph::E(g2))

edges <- as.data.frame(edges)
edges$from <- nodes2cellID[edges$V1]
edges$to <- nodes2cellID[edges$V2]
edges$from.x <- cell.embeddings[edges$from, 1]
edges$from.y <- cell.embeddings[edges$from, 2]
edges$to.x <- cell.embeddings[edges$to, 1]
edges$to.y <- cell.embeddings[edges$to, 2]

DimPlot(seu, reduction = "fr", cells.highlight = data.use$cellID) +
  geom_segment(inherit.aes = F, data = edges,
               mapping = aes(x = from.x, y = from.y, xend = to.x, yend = to.y), alpha=1)



#### Lineage choice: 最短路径算法 ####
root.cells <- "OSCC15_AGTCATGGTTATAGCC"
terminal.cells <- c(
  "F06" = "OSCC14_ATGAAAGTCTCGGGAC",
  "F03"="OSCC15_CTGATCCCACCGCTGA" ,
  "F04"="OSCC15_TGTCCCACATGGCCCA",
  "F08" = "OSCC14_CATGGATAGACGCTCC",
  "F07" = "OSCC8_CGAGCACCAATAAGCA"
)
nodes2cluster <- seu$seurat_clusters[nodes2cellID]
cluster2nodes <- setNames(names(nodes2cluster), nodes2cluster)

terminal.nodes <- cellID2nodes[cluster2nodes[seu$seurat_clusters[terminal.cells]]]
names(terminal.nodes) <- names(terminal.cells)

root.nodes <- cellID2nodes[cluster2nodes[seu$seurat_clusters[root.cells]]]

result <- igraph::shortest_paths(mst, from = root.nodes, to = terminal.nodes) ## modify me
lineages <- result$vpath
names(lineages) <- names(terminal.nodes)

DimPlot(seu, reduction = "fr", cells.highlight = nodes2cellID[lineages$F06])

## cellID2lineage
seu$lineage.F06 <- seu$seurat_clusters %in% nodes2cluster[lineages$F06]
DimPlot(seu, reduction = "fr", group.by = "lineage.F06")

## for loop
for (i in seq_along(lineages)) {
  ln <- names(lineages)[i]
  meta.name <- glue::glue("lineage.{ln}")
  seu[[meta.name]] <- seu$seurat_clusters %in% nodes2cluster[lineages[[i]]]
}

DimPlot(seu, reduction = "fr", group.by = paste0("lineage.", names(lineages)), ncol = 3) &
  scale_color_manual(values = c("grey", "red")) &
  NoLegend()


#### Fine tune cells along the lineage: Principle curve ####
source("R/lineage.R")

## fit the principle curve
p.curve.F06 <- fit_pc(seu, lineage = "lineage.F06", reduction = "fr")#, sample.n = 100 # 6
p.curve.F03 <- fit_pc(seu, lineage = "lineage.F03", reduction = "fr") # 5
p.curve.F04 <- fit_pc(seu, lineage = "lineage.F04", reduction = "fr") # 3
p.curve.F08 <- fit_pc(seu, lineage = "lineage.F08", reduction = "fr")#, sample.n = 100 # 5
p.curve.F07 <- fit_pc(seu, lineage = "lineage.F07", reduction = "fr") # 6



## plot on FR
data.point <- FetchData(seu, vars = c(paste0("FDG_", 1:2), "celltype"))
data.path.F06 <- get_path(p.curve.F06, df=6)
data.arrow.F06 <- get_arrow(data.path.F06, reverse = T)

data.path.F03 <- get_path(p.curve.F03, df=5)
data.arrow.F03 <- get_arrow(data.path.F03, reverse = T)

data.path.F04 <- get_path(p.curve.F04, df=3)
data.arrow.F04 <- get_arrow(data.path.F04, reverse = T)

data.path.F08 <- get_path(p.curve.F08, df=5)
data.arrow.F08 <- get_arrow(data.path.F08, reverse = F)

data.path.F07 <- get_path(p.curve.F07, df=6)
data.arrow.F07 <- get_arrow(data.path.F07, reverse = F)


p1<- ggplot() +
 geom_point(data = data.point, aes(FDG_1, FDG_2, color = celltype), size = .2) +

  geom_path(data = data.path.F06, aes(X,Y), size = .8) +
  geom_segment(data = data.arrow.F06, aes(x = X, xend = Xend, y = Y, yend = Yend),
               arrow = arrow(length = unit(0.1, "in"), angle = 30, type = "closed"), size = .5) +

  geom_path(data = data.path.F03, aes(X,Y), size = .8) +
  geom_segment(data = data.arrow.F03, aes(x = X, xend = Xend, y = Y, yend = Yend),
               arrow = arrow(length = unit(0.1, "in"), angle = 30, type = "closed"), size = .5) +

  geom_path(data = data.path.F08, aes(X,Y), size = .8) +
  geom_segment(data = data.arrow.F08, aes(x = X, xend = Xend, y = Y, yend = Yend),
               arrow = arrow(length = unit(0.1, "in"), angle = 30, type = "closed"), size = .5) +

  geom_path(data = data.path.F07, aes(X,Y), size = .8) +
  geom_segment(data = data.arrow.F07, aes(x = X, xend = Xend, y = Y, yend = Yend),
               arrow = arrow(length = unit(0.1, "in"), angle = 30, type = "closed"), size = .5) +

  theme_classic(base_size = 15)+
  guides(color = guide_legend(override.aes = list(size = 5)))
#####先不画F04线
# geom_path(data = data.path.F04, aes(X,Y), size = .8) +
#   geom_segment(data = data.arrow.F04, aes(x = X, xend = Xend, y = Y, yend = Yend),
#                arrow = arrow(length = unit(0.1, "in"), angle = 30, type = "closed"), size = .5) +

## cells around the curve
seu <- cells_on_lineage(seu, lineage = "F06", reduction = "fr", data.path = data.path.F06, delta = 0.1)
DimPlot(seu, reduction = "fr", group.by = "lineage.finetune.F06") +
  scale_color_manual(values = c("grey", "red"))

seu <- cells_on_lineage(seu, lineage = "F03", reduction = "fr", data.path = data.path.F03)
DimPlot(seu, reduction = "fr", group.by = "lineage.finetune.F03") +
  scale_color_manual(values = c("grey", "red"))


seu <- cells_on_lineage(seu, lineage = "F04", reduction = "fr", data.path = data.path.F04)
seu <- cells_on_lineage(seu, lineage = "F08", reduction = "fr", data.path = data.path.F08)
seu <- cells_on_lineage(seu, lineage = "F07", reduction = "fr", data.path = data.path.F07)


## 结合lineage probability信息
seu$lineage.finetune.F06 <- seu$lineage.finetune.F06 | seu$F06 > 0.5
seu$lineage.finetune.F03<- seu$lineage.finetune.F03 | seu$F03> 0.5
seu$lineage.finetune.F04 <- seu$lineage.finetune.F04 | seu$F04 > 0.5
seu$lineage.finetune.F08 <- seu$lineage.finetune.F08 | seu$F08 > 0.5
seu$lineage.finetune.F07 <- seu$lineage.finetune.F07 | seu$F07 > 0.5


DimPlot(seu, reduction = "fr", group.by = paste0("lineage.finetune.", names(terminal.cells)), cols = 3) &
  scale_color_manual(values = c("grey", "red")) &
  NoLegend()

qs::qsave(seu, "tmp/08.OSCCall_donor1.seurat.lineage.qs")

##拼图

p2 <- DimPlot(seu, reduction = "fr", group.by = "lineage.F06")+
  scale_color_manual(values = c("grey", "red")) +
  NoLegend() + ggtitle("lineage.F06")

seu <- cells_on_lineage(seu, lineage = "F03", reduction = "fr", data.path = data.path.F03)
seu$lineage.finetune.F03<- seu$lineage.finetune.F03 | seu$F03> 0.5
p3 <- DimPlot(seu, reduction = "fr", group.by = "lineage.finetune.F03") +
  scale_color_manual(values = c("grey", "red"))+
  NoLegend() + ggtitle("lineage.F03")
p4 <- DimPlot(seu, reduction = "fr", group.by = "lineage.F04") +
  scale_color_manual(values = c("grey", "red")) +
  NoLegend() + ggtitle("lineage.F04")
p5<- DimPlot(seu, reduction = "fr", group.by = "lineage.F08") +
  scale_color_manual(values = c("grey", "red")) +
  NoLegend() + ggtitle("lineage.F08")
p6 <- DimPlot(seu, reduction = "fr", group.by = "lineage.F07") +
  scale_color_manual(values = c("grey", "red")) +
  NoLegend() + ggtitle("lineage.F07")
p1+p2+p3+p4+p5+p6
p3+p4+p2+p6+p5

