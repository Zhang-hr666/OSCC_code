## Rmagic for data imputation
install.packages("Rmagic")
# reticulate::install_miniconda() # if do not have reticulate conda env
reticulate::py_install("magic-impute")
## Gadest for Variance Decomposition
# devtools::install_github("JarningGau/Gadest)

#### Load packages ####
library(Seurat)
library(tidyverse)
library(mgcv)

setwd(here::here())

#### Load data ####
seu <- qs::qread("tmp/08.")

## Imputation by `MAGIC`(https://github.com/KrishnaswamyLab/MAGIC)
expr.in.cells <- Matrix::rowSums(seu[["RNA"]]@counts > 0)
select.features <- names(expr.in.cells[expr.in.cells >= 50])
seu.magic <- Rmagic::magic(seu, genes = select.features, seed=1024, npcs=30)
DefaultAssay(seu.magic) <- "MAGIC_RNA"

## Ery lineage
seu.Ery <- subset(seu.magic, lineage.finetune.Ery)

## check the results
DefaultAssay(seu.Ery) <- "RNA"
p1 <- FeaturePlot(seu.Ery, reduction = "fr", features = "HBB")
DefaultAssay(seu.Ery) <- "MAGIC_RNA"
p2 <- FeaturePlot(seu.Ery, reduction = "fr", features = "HBB")
(p1 | p2) & scale_color_viridis_c()

### DP
data.use <- FetchData(seu.Ery, vars = c("DP", "pseudotime", "celltype"))
data.use <- arrange(data.use, pseudotime)

ggplot(data.use, aes(pseudotime, DP, color = celltype, group = celltype)) +
  geom_point(size = .5) +
  ggsci::scale_color_d3() +
  guides(color = guide_legend(override.aes = list(size = 4))) +
  theme_classic(base_size = 15)

### fit the curve 线性可加模型(LAM)
model <- gam(DP ~ s(pseudotime), data = data.use) ## via `mgcv` package
data.use$fitted <- model$fitted.values

## 一阶微分:找到DP变化最大的位置
data.use$diff <- abs(c(NA, diff(data.use$fitted) / diff(data.use$pseudotime)))
## Max-min标准化到0-1区间
data.use$diff <- (data.use$diff - min(data.use$diff, na.rm = T)) / (max(data.use$diff, na.rm = T) - min(data.use$diff, na.rm = T))

## 二阶微分：确定极值点
data.use$diff.diff <- abs(c(NA, diff(data.use$diff) / diff(data.use$pseudotime)))

ggplot(data.use, aes(pseudotime, DP, color = celltype, group = celltype)) +
  geom_point(size = .5) +
  geom_vline(xintercept = c(0.152, 0.382)) +
  geom_point(aes(pseudotime, fitted), color = "red", size = .1) +
  geom_point(aes(pseudotime, diff), color = "blue", size = .1) +
  ggsci::scale_color_d3() +
  guides(color = guide_legend(override.aes = list(size = 4))) +
  theme_classic(base_size = 15)

data.DP <- data.use

### related genes
data.use <- FetchData(seu.Ery, vars = c(rownames(seu.Ery), "pseudotime", "Ery"))
cor.test <- cor(data.use[, 1:(length(data.use)-2)], data.use$Ery)

cor.res.df <- data.frame(
  term = rownames(cor.test),
  corr = cor.test[,1]
)

FeaturePlot(seu, reduction = "fr", features = c("Ery", "KLF1", "GATA1", "MPST"), ncol = 2) &
  scale_color_viridis_c()

FeaturePlot(seu.magic, reduction = "fr", features = c("Ery", "KLF1", "GATA1", "MPST"), ncol = 2) &
  scale_color_viridis_c()

## LMM model
seu.Ery$pseudotime.bin <- infotheo::discretize(seu.Ery$pseudotime, disc = "equalwidth", 100)[[1]]
expr.in.cells <- Matrix::rowSums(seu.Ery[["RNA"]]@counts > 0)
select.features <- names(expr.in.cells[expr.in.cells >= 50])
imputed.data <- FetchData(seu.Ery, vars = select.features)
vd.vars <- c("pseudotime.bin")
meta.data <- seu.Ery@meta.data[, vd.vars, drop = F]

dim(imputed.data) ## 10750 genes

## 48s
system.time({
  vd.res <- Gadest::VarDecompose(data = imputed.data, meta.data = meta.data, vd.vars = vd.vars, cores = 20)
})

vd.res$Ery.corr <- cor.res.df[vd.res$gene, "corr"]

ggplot(vd.res, aes(pseudotime.bin, Ery.corr)) +
  geom_point(size = .1)

## 感受一下方差分解的好处
head(subset(vd.res, abs(Ery.corr)<0.1 & pseudotime.bin > 0.75))

FeaturePlot(seu.magic, reduction = "fr", features = c("Ery", "THRB", "RGS18", "GATA2"), ncol = 2) &
  scale_color_viridis_c()

##
all.DEGs <- subset(vd.res, pseudotime.bin > 0.5)
dim(all.DEGs)

## gene cluster:

## visualization
data.use <- FetchData(seu.Ery, vars = c("pseudotime", "DP", "KLF1", "GATA1", "celltype"))

ggplot(data.use, aes(pseudotime, GATA1)) +
  geom_point(aes(color = celltype), size = 1, alpha = .5) +
  geom_vline(xintercept = c(0.152, 0.382)) +
  geom_smooth() +
  geom_point(inherit.aes = F, data = data.DP, aes(pseudotime, fitted), size = .1, color = "red") +
  geom_point(inherit.aes = F, data = data.DP, aes(pseudotime, diff), size = .1, color = "orange") +
  theme_classic(base_size = 15)

