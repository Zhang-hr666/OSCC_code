library(Seurat)
library(tidyverse)


seu <- SeuratDisk::LoadH5Seurat("tmp/06.HS_BM_donor1.h5Seurat")
seu <- subset(seu, celltype %in% c("HSC","Ery"))

var.df <- data.frame(
  gene.name = rownames(seu[["spliced"]]),
  spliced.mean = Matrix::rowMeans(seu[["spliced"]]),
  unspliced.mean = Matrix::rowMeans(seu[["unspliced"]])
)

writeLines(subset(var.df, spliced.mean > unspliced.mean)$gene.name, "tmp/07-2.more_spliced_genes.txt")

ggplot(var.df, aes(spliced.mean, unspliced.mean)) +
  geom_point() +
  geom_abline(slope = 1, intercept = 0)

## 我们可以把scVelo的关键结果存入Seurat里作为不同的assay
velo <- read.table("tmp/07_HS_BM_donor1.Ery_lineage.velo.csv", sep = ",", header = T, row.names = 1)
colnames(velo) <- paste0("velo-", colnames(velo))
seu[["velocity"]] <- CreateAssayObject(data = t(velo))

Ms <- read.table("tmp/07_HS_BM_donor1.Ery_lineage.Ms.csv", sep = ",", header = T, row.names = 1)
colnames(Ms) <- paste0("Ms-", colnames(Ms))
seu[["Ms"]] <- CreateAssayObject(data = t(Ms))

Mu <- read.table("tmp/07_HS_BM_donor1.Ery_lineage.Mu.csv", sep = ",", header = T, row.names = 1)
colnames(Mu) <- paste0("Mu-", colnames(Mu))
seu[["Mu"]] <- CreateAssayObject(data = t(Mu))

## 这样，我们就可以在R环境中对结果可视化
FeaturePlot(seu, reduction = "fr", features = c("Mu-ZBTB16", "Ms-ZBTB16")) &
  scale_color_viridis_c()

FeatureScatter(seu, feature1 = "Ms-ZBTB16", feature2 = "Mu-ZBTB16", group.by = "celltype")


